import React from 'react'

const Navbar = () => {
  return (
    <nav>
        <div className="nav-heading">
            Perficient National Bank
        </div>
    </nav>
  )
}

export default Navbar