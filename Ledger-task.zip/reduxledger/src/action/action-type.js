export const ADD_AMOUNT = "ADD_AMOUNT";
export const REMOVE_AMOUNT = "REMOVE_AMOUNT";