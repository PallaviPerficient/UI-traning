import './App.css';
import Formdata from './Component/formdata';

function App() {
  return (
    <div className="App">
      <h1>Local Storage</h1>
      <Formdata/>
    </div>
  );
}

export default App;
