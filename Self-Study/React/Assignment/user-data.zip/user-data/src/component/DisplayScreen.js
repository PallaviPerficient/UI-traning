import React from 'react'
import Table from './Table';
const DisplayScreen = (props) => {
  console.log(props);
  return (
    <div>
      <h1>Table</h1>
      <Table  />
    </div>
  )
}

export default DisplayScreen
