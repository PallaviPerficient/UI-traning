//logic

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import DisplayScreen from "../component/DisplayScreen";
import Table from "./Table";

const UserScreen = (props) => {
  const navigate = useNavigate();

  const [getdata, Setgetdata] = useState([]);
  const [data, Setdata] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    company: "",
    profile_url: " ",
  });

  const handleChange = (e) => {
    const newInput = () => ({ ...data, [e.target.name]: e.target.value });
    Setdata(newInput);
  };

  const Submit = (e) => {
    e.preventDefault();
    const newData = (obj) => [...obj, data];
    Setgetdata(newData);
    // navigate('/displayscreen');
  };

  function allLetter(inputtxt) {
    var letters = /^[A-Za-z]+$/;
    if (inputtxt.value.match(letters)) {
      alert("Your name have accepted : you can try another");
      return true;
    } else {
      alert("Please input alphabet characters only");
      return false;
    }
  }

  console.log(data);
  console.log(getdata);
  return (
    <div>
      <form onSubmit={Submit}>
        <label>First Name :</label>
        <input name="first_name" type='text'  pattern="^[0-9\b]+$"  onChange={handleChange} required />

        <br />

        <label>Last Name :</label>
        <input type='text' name="last_name" onChange={handleChange} required />

        <br />

        <label>Email:</label>
        <input type="email" name="email" onChange={handleChange} required />

        <br />

        <label>Mobile Number :</label>
        <input type="number" name="phone" maxLength={15} onChange={handleChange} required />

        <br />

        <label>Comapny :</label>
        <input type='text' name="company" onChange={handleChange} required />

        <br />

        <label>Profile Url:</label>
        <input type="url" name="profile_url" onChange={handleChange} />

        <br />

        <button type="Submit"> Submit </button>
      </form>
      <Table tabledata={getdata} />
    </div>
  );
};

export default UserScreen;
