import Header from "./Component/Header";
import './App.scss'; 

function App() {
  return (
    <div className="App">
      <Header />
    </div>
  );
}

export default App;
