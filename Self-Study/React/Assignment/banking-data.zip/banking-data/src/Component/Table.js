import React from 'react'
import './Table.css'

const Table = (props) => {
    let date = props.date ? props.date.getDate() + "-"+ parseInt(props.date.getMonth()+1) +"-"+props.date.getFullYear(): null
    return(
        <>
        <table>
            <thead className=''>
                <tr>
                    <th>Sr.No</th>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Check Number</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
            {
                props?.tabledata?.map((item, index)=>{
                    return(
                        <tr key={index}>
                            <td>{index+1}</td>
                            <td>{date}</td>
                            <td>{item.type}</td>
                            <td>{item.check_number}</td>
                            <td>{item.amount}</td>
                      
                        </tr>
                    )
                })
            }
            </tbody>
        </table>
        </>

       
    );

}

export default Table;