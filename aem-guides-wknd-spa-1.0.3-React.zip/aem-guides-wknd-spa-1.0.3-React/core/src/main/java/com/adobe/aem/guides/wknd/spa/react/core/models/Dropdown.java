package com.adobe.aem.guides.wknd.spa.react.core.models;
import com.adobe.cq.export.json.ComponentExporter;

public interface Dropdown extends ComponentExporter{
    public String getdropdown();
}
