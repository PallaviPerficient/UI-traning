const data={

    productItems:[

        {

            id:1,

            name:"Beats Headphone 1",

            price:999,

            image:"https://th.bing.com/th/id/OIP.V-w8vv32wZAQi1gsxQLFJQHaHa?pid=ImgDet&rs=1"

        },

        {

            id:2,

            name:"Beats Headphone 2",

            price:999,

            image:"https://image.oppo.com/content/dam/oppo/common/mkt/v2-2/reno8-5g-en/middlebanner/reno8-shimmer-gold-640x480-6-mobile.jpg.thumb.webp"

        },

        {

            id:3,

            name:"Beats Headphone 3",

            price:999,

            image:"https://image.oppo.com/content/dam/oppo/common/mkt/v2-2/a16/middlebanner/A16-middlebanner-blue-640x480-mobile.jpg.thumb.webp "

        },

        {

            id:4,

            name:"Beats Headphone 4",

            price:999,

            image:" https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAUZej7qmway3t79r7LtXMsAfLKTfy-HrrDg&usqp=CAU"

        },

        {

            id:5,

            name:"Beats Headphone 5",

            price:999,

            image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxRYS0F2f6k7LYqtANHJ7EdTBIq22DUUwGyA&usqp=CAU"

        },

        {

            id:6,

            name:"Beats Headphone 6",

            price:999,

            image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-ZUMoomY-fb-iPrYbTaReKhLRhJo5IV__Yg&usqp=CAU"

        },




    ]

}




export default data;